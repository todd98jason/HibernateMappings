package OnetoMany_bidirectional;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TnSDriver 
{
	public static void main(String[] args) {
		
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
	EntityManager manager = factory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	
	//creating objects for teachers
	Teacher t1 = new Teacher();
	Teacher t2 = new Teacher();
	
	
	//creating objects for Students
	Student s1 = new Student();
	Student s2 = new Student();
	Student s3 = new Student();
	Student s4 = new Student();
	
	//t1
	t1.setT_name("priya");
	t1.setT_subject("java");
	
	//t2
	t2.setT_name("supriya");
	t2.setT_subject("javascript");
	
	
	
	//s1
	s1.setS_name("sam");
	s1.setS_subject("java");
	
	
	//s2
		s2.setS_name("ram");
		s2.setS_subject("java");
		

	//s3
	s3.setS_name("vam");
	s3.setS_subject("javaScript");
	
	
	//s4
		s4.setS_name("mam");
		s4.setS_subject("java");

	
	List<Student> kid = new ArrayList<Student>();
	kid.add(s1);
	kid.add(s2);
	
	
	t1.setKid(kid);
	
	
	List<Student> kidssss = new ArrayList<Student>();
	kidssss.add(s3);
	kidssss.add(s4);

	t2.setKid(kidssss);
	
	s1.setTeach(t1);
	s2.setTeach(t1);
	
	s3.setTeach(t2);
	s4.setTeach(t2);
	
	
	
	transaction.begin();
	manager.persist(t1);
	manager.persist(t2);
	manager.persist(s1);
	manager.persist(s2);
	manager.persist(s3);
	manager.persist(s4);
	transaction.commit();
	
	
	
	}
}
