package OnetoMany_UniDirectional;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class QnADriver 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		//create a question
		Question q = new Question();
		q.setQuestion_name("what is java");
		q.setMarks(5);
		
		//creating answer 1
		
		Answer a1 = new Answer();
		a1.setAnswer_name("high level language");
		
		//creating answer 2
		Answer a2 = new Answer();
		a2.setAnswer_name("platform Independent");
		
		//creating answer 3
		Answer a3 =  new Answer();
		a3.setAnswer_name("robust and secure");
		
		//storing all the answers of one question in a list
		List<Answer> answers = new ArrayList<Answer>();
		answers.add(a1);
		answers.add(a2);
		answers.add(a3);
		
		//setting the list to the question
		q.setAnswers(answers);
		
		transaction.begin();
		manager.persist(q);
		manager.persist(a1);
		manager.persist(a2);
		manager.persist(a3);
		transaction.commit();
	}

}
