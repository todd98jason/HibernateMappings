package OnetoOne_biDirectional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CustPro_Driver 
{
	public static void main(String[] args) {
		
		EntityManagerFactory f = Persistence.createEntityManagerFactory("dev");
		EntityManager m = f.createEntityManager();
		EntityTransaction t = m.getTransaction();
		
		Customer c1 = new Customer();
		Customer c2 = new Customer();
		
		Product p1 = new Product();
		Product p2 = new Product();
		
		//add value to the customer
		c1.setName("parthi");
		c1.setLoc("kashmir");
		c1.setProduct(p1);
		
		c2.setName("leo");
		c2.setLoc("andra");
		c2.setProduct(p1);
		
		//adding value to the product
		p1.setPro_name("gun");
		p1.setPrice(2000.20);
		p1.setCustomer(c2);
		
		p2.setPro_name("cage");
		p2.setPrice(300.40);
		p2.setCustomer(c1);
		
		t.begin();
		m.persist(c1);
		m.persist(c2);
		m.persist(p1);
		m.persist(p2);
		t.commit();
	}

}
