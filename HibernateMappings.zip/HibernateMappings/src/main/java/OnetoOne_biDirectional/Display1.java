package OnetoOne_biDirectional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Display1 
{
	public static void main(String[] args) {
		EntityManagerFactory f = Persistence.createEntityManagerFactory("dev");
		EntityManager m = f.createEntityManager();
		
		//using customer obj
		
		Customer c = m.find(Customer.class, 1);
		System.out.println("-----first customer details-----");
		System.out.println(c.getCust_id()+", "+c.getName()+", "+c.getLoc()+", "+c.getProduct().getPro_name()+", "+c.getProduct().getPrice());
		
		Customer c1 = m.find(Customer.class, 2);
		System.out.println("-----Second customer details-----");
		System.out.println(c1.getCust_id()+", "+c1.getName()+", "+c1.getLoc()+", "+c1.getProduct().getPro_name()+", "+c1.getProduct().getPrice());
		
	}

}
