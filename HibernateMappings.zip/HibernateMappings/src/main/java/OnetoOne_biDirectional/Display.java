package OnetoOne_biDirectional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Display 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		
		//using Car object
		Car c = manager.find(Car.class, 1);
		System.out.println("--------using CAR object-----------");
		System.out.println("Car details:");
		System.out.println(c.getBrand()+", "+c.getPrice());
		System.out.println("Engine details:");
		System.out.println(c.getE().getType()+", "+c.getE().getPrice());
		
		//using Engine object
		Engine e = manager.find(Engine.class, 1);
		System.out.println("--------using ENGINE object-----------");
		System.out.println("Engine details:");
		System.out.println(e.getType()+", "+e.getPrice());
		System.out.println("Car details:");
		System.out.println(e.getC().getBrand()+", "+e.getC().getPrice());
		
	}

}
