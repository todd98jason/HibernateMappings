package OnetoOne_biDirectional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CarDriver 
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		Car c1 = new Car();
		Car c2 = new Car();
		//adding values to the engine
		Engine e1 = new Engine();
		e1.setType("petrol");
		e1.setPrice(2000.20);
		e1.setC(c1);
		
		Engine e2 = new Engine();
		e2.setType("diesel");
		e2.setPrice(1000.20);
		e2.setC(c2);
		
		
		//adding values to the car
		
		c1.setBrand("volvo");
		c1.setE(e1);
		c1.setPrice(300000.5);

		
		c2.setBrand("skoda");
		c2.setE(e2);
		c2.setPrice(350000.5);
		
		transaction.begin();
		manager.persist(c1);
		manager.persist(c2);
		manager.persist(e1);
		manager.persist(e2);
		transaction.commit();

	}

}
