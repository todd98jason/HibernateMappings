package ManytoMany_BiDirectional;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Cus_pro_Driver 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		//create customer no.1
		Customer1 c1 = new Customer1();
		c1.setName("traitor");
		
		//create customer no.2
		Customer1 c2 = new Customer1();
		c2.setName("BackStabber");
		
		//create customer no.3
		Customer1 c3 = new Customer1();
		c3.setName("cunning");
		
		//create product no1
		Product1 p1 = new Product1();
		p1.setPro_name("television");
		p1.setPro_price(4500);
		
		//create product no1
		Product1 p2 = new Product1();
		p2.setPro_name("playstation");
		p2.setPro_price(5000);
		
		//creating a list for Customer
		List<Customer1> customers = new ArrayList<Customer1>();
		customers.add(c1);
		customers.add(c2);
		customers.add(c3);
		
		//creating a list for products
		List<Product1> products = new ArrayList<Product1>();
		products.add(p1);
		products.add(p2);
		
		//setting products to the customer
		c1.setProd(products);
		c2.setProd(products);
		c3.setProd(products);
		
		//setting customers to product
		p1.setCust(customers);
		p2.setCust(customers);
		
		//store all objects to DB
		transaction.begin();
		manager.persist(c1);
		manager.persist(c2);
		manager.persist(c3);
		manager.persist(c3);
		manager.persist(p1);
		manager.persist(p2);
		transaction.commit();
		
		
	}

}
