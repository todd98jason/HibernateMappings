package ManytoMany_BiDirectional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DisplayCus_pro 
{
	public static void main(String[] args) {
		
		EntityManagerFactory f = Persistence.createEntityManagerFactory("dev");
		EntityManager m = f.createEntityManager();
		
		System.out.println("====customer&product====");
		Customer1 c = m.find(Customer1.class, 1);
		Customer1 c1 = m.find(Customer1.class, 2);
		System.out.println(c.getCus_id()+", "+c.getName()+", "+c.getProd());
		
	}

}
