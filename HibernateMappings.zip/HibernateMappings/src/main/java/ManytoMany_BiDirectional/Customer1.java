package ManytoMany_BiDirectional;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Customer1 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cus_id;
	private String name;

	@ManyToMany
	List<Product1> prod;

	public int getCus_id() {
		return cus_id;
	}

	public void setCus_id(int cus_id) {
		this.cus_id = cus_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Product1> getProd() {
		return prod;
	}

	public void setProd(List<Product1> prod) {
		this.prod = prod;
	}

	
}
