package OnetoOne_uniDirectional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmpDriver 
{
	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		
		//create address object
		Address a1 = new Address();
		a1.setCity("bangalore");
		a1.setState("karnataka");

		Address a2 = new Address();
		a2.setCity("Nandi hills");
		a2.setState("karnataka");
		
		//create employee object
		Employee e = new Employee();
		e.setName("don");
		e.setDesignation("HR");
		e.setAddress(a1);
		
		transaction.begin();
		manager.persist(a1);
		manager.persist(a2);
		manager.persist(e);
		transaction.commit();
	}

}
