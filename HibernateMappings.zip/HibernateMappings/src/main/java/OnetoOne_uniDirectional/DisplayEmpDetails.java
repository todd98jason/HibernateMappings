package OnetoOne_uniDirectional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DisplayEmpDetails 
{
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		EntityManager manager = factory.createEntityManager();
		
		Employee emp = manager.find(Employee.class, 1);
		System.out.println("details using employee");
		System.out.println(emp.getEmp_id()+", "+emp.getName());
		System.out.println(emp.getDesignation());
		
		Address a = emp.getAddress();
		System.out.println(a.getCity()+", "+a.getState());
	}

}
